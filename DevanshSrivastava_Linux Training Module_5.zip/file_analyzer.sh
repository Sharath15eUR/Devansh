#!/bin/bash

LOG_FILE_ERROR="error.log"

show_help() {
    cat << 'HELP'
Simple File Search Tool

Usage:
    ./file_analyzer.sh -d folder -k word    Search in folder
    ./file_analyzer.sh -f file -k word      Search in file
    ./file_analyzer.sh --help               Show help

Options:
    -d: Directory to search
    -k: Word to find
    -f: File to search
HELP
}


search_folder() {
    local folder=$1
    local word=$2

    for item in "$folder"/*; do
        if [ -d "$item" ]; then
            search_folder "$item" "$word"
        elif [ -f "$item" ]; then
            if grep -Hn --color "$word" "$item"; then
                echo "---"
            fi
        else
            echo "Warning: Skipped unknown item: $item" >> "$LOG_FILE_ERROR"
        fi
    done
}


if [ "$1" = "--help" ]; then
    show_help
    exit 0
fi


while getopts "d:k:f:" opt; do
    case $opt in
        d) folder="$OPTARG" ;;
        k) word="$OPTARG" ;;
        f) file="$OPTARG" ;;
        ?) 
            show_help
            echo "Error: Invalid option provided" >> "$LOG_FILE_ERROR"
            exit 1 
        ;;
    esac
done


if [[ -z "$word" || "$word" =~ ^[[:space:]]*$ ]]; then
    echo "Error: Please provide a non-empty keyword (-k)." | tee -a "$LOG_FILE_ERROR"
    show_help
    exit 1
fi

if [[ -n "$folder" && ! -d "$folder" ]]; then
    echo "Error: Directory not found: $folder" | tee -a "$LOG_FILE_ERROR"
    exit 1
fi

if [[ -n "$file" && ! -f "$file" ]]; then
    echo "Error: File not found: $file" | tee -a "$LOG_FILE_ERROR"
    exit 1
fi

if [[ -z "$folder" && -z "$file" ]]; then
    echo "Error: Please provide either a directory (-d) or a file (-f)." | tee -a "$LOG_FILE_ERROR"
    show_help
    exit 1
fi


if [[ -n "$folder" ]]; then
    search_folder "$folder" "$word" 2>>"$LOG_FILE_ERROR"
elif [[ -n "$file" ]]; then
    echo "Searching in file: $file"
    grep --color=always "$word" "$file" || {
        echo "No matches found." 
        echo "Warning: No matches found in file: $file" >> "$LOG_FILE_ERROR"
    }
fi

